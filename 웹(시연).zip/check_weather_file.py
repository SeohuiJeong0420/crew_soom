import pandas as pd
import os

try:
    file_path = 'today_data/오늘날씨.xlsx'
    if os.path.exists(file_path):
        df = pd.read_excel(file_path)
        print("📋 파일 존재: ✅")
        print("📊 데이터 내용:")
        print(df.to_string())
        print("\n🔍 컬럼명:")
        print(list(df.columns))
        print("\n📏 데이터 크기:", df.shape)
        
        # 각 컬럼의 값 확인
        print("\n🎯 각 컬럼 값:")
        for col in df.columns:
            print(f"  {col}: {df[col].iloc[0]}")
            
    else:
        print("❌ 파일이 존재하지 않습니다:", file_path)
except Exception as e:
    print("🚨 파일 읽기 오류:", e)
