import os
import pandas as pd
from datetime import datetime

def fix_excel_issues():
    """Excel 파일 문제 해결"""
    
    # 임시 파일 삭제
    temp_file = "today_data/~$오늘날씨.xlsx"
    if os.path.exists(temp_file):
        try:
            os.remove(temp_file)
            print("✅ 임시 파일 삭제 완료")
        except:
            print("❌ 임시 파일 삭제 실패")
    
    # 새로운 테스트 데이터 생성
    weather_data = {
        '날짜': datetime.now().strftime("%Y년 %m월 %d일"),
        '현재온도': '현재온도28.0°',
        '날씨상태': '맑음',
        '날씨상세': '맑음', 
        '강수량': '0mm',
        '미세먼지': '보통',
        '초미세먼지': '보통'
    }
    
    df = pd.DataFrame([weather_data])
    df.to_excel('today_data/오늘날씨.xlsx', index=False)
    print("✅ 새로운 날씨 데이터 생성 완료")
    print(f"🌡️ 온도: {weather_data['현재온도']}")

if __name__ == "__main__":
    fix_excel_issues()
