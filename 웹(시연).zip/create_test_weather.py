import pandas as pd
import os
from datetime import datetime

def create_test_weather_data():
    """테스트용 날씨 데이터 생성"""
    
    # today_data 디렉토리가 없으면 생성
    os.makedirs('today_data', exist_ok=True)
    
    # 현재 실제 날씨에 가까운 데이터 생성
    weather_data = {
        '날짜': datetime.now().strftime("%Y년 %m월 %d일"),
        '현재온도': '현재온도27.0°',
        '날씨상태': '맑음',
        '날씨상세': '맑음', 
        '강수량': '0mm',
        '미세먼지': '보통',
        '초미세먼지': '보통'
    }
    
    # DataFrame으로 변환
    df = pd.DataFrame([weather_data])
    
    # Excel 파일로 저장
    filename = 'today_data/오늘날씨.xlsx'
    df.to_excel(filename, index=False)
    
    print("✅ 테스트 날씨 데이터 생성 완료!")
    print(f"📁 파일 위치: {filename}")
    print(f"🌡️ 온도: {weather_data['현재온도']}")
    print(f"☁️ 날씨: {weather_data['날씨상세']}")
    print(f"💧 강수량: {weather_data['강수량']}")
    
    return filename

if __name__ == "__main__":
    create_test_weather_data()
